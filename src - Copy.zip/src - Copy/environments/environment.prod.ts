export const environment = {
  production: true,
  nome: '',
  id: 0,
  foto: '',
  token: ''
};
